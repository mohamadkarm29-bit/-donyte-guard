package com.example.donyteguard

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class ChatMessage(val text: String, val fromMe: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DonyteGuardApp() }
    }
}

/*
 * Demo word list only. Replace these placeholders with terms that both
 * participants agree to flag. This prototype checks text on this device only.
 */
private val flaggedTerms = setOf(
    "كلمة_غير_مناسبة",
    "لفظ_مسيء"
)

private fun findFlaggedTerm(message: String): String? {
    val normalized = message.lowercase()
    return flaggedTerms.firstOrNull { term -> normalized.contains(term.lowercase()) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DonyteGuardApp() {
    var draft by remember { mutableStateOf("") }
    var warning by remember { mutableStateOf<String?>(null) }
    val messages = remember {
        mutableStateListOf(
            ChatMessage("أهلًا! دي محادثة تجريبية داخل Donyte Guard.", false)
        )
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Donyte Guard", fontWeight = FontWeight.Bold)
                            Text("محادثة تجريبية مع Donyte", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
            ) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                    )
                ) {
                    Text(
                        "النموذج الأولي: الرسائل محفوظة مؤقتًا داخل الشاشة فقط، ولا تصل للطرف الآخر.",
                        modifier = Modifier.padding(12.dp),
                        style = MaterialTheme.typography.bodySmall
                    )
                }

                Spacer(Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(messages) { message ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (message.fromMe) Arrangement.End else Arrangement.Start
                        ) {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = if (message.fromMe)
                                    MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    message.text,
                                    modifier = Modifier.widthIn(max = 280.dp).padding(12.dp)
                                )
                            }
                        }
                    }
                }

                warning?.let {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            it,
                            modifier = Modifier.padding(12.dp),
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                }

                OutlinedTextField(
                    value = draft,
                    onValueChange = {
                        draft = it
                        warning = null
                    },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("اكتب رسالتك") },
                    minLines = 2,
                    maxLines = 4
                )
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = {
                        val text = draft.trim()
                        if (text.isNotEmpty()) {
                            val flagged = findFlaggedTerm(text)
                            if (flagged != null) {
                                warning = "تم إيقاف الإرسال التجريبي: راجع صياغة الرسالة واحذف اللفظ غير المناسب."
                            } else {
                                messages.add(ChatMessage(text, true))
                                draft = ""
                                warning = null
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("مراجعة ثم إرسال تجريبي")
                }
                Text(
                    "لن يتم إرسال أي شيء عبر واتساب أو الإنترنت في هذا الإصدار.",
                    style = MaterialTheme.typography.labelSmall,
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 8.dp)
                )
            }
        }
    }
}
