# Donyte Guard — Android prototype

This is a **local UI prototype**, not a connected chat service.

## What works
- Android chat-style screen.
- Checks a draft against a small placeholder list before adding it to the local demo chat.
- Blocks the demo send when a flagged placeholder term is found.
- No network permissions, analytics, or remote storage.

## What does not work yet
- Messages do not reach Donyte's phone.
- There is no account system, live sync, push notification, or WhatsApp integration.
- The sample flagged terms are placeholders, not a complete Arabic language filter.

## Open in Android Studio
1. Install Android Studio with Android SDK 35.
2. Choose **Open** and select this project folder.
3. Allow Gradle sync.
4. Run the `app` configuration on an Android device or emulator.

## Next step for a two-person live chat
A live two-device chat needs a backend or peer-to-peer service, participant authentication, transport security, message retention/deletion rules, and notification delivery. Both participants should knowingly join the same private room. Do not put private credentials or API keys in the Android source code.

The current prototype deliberately does not transmit or store chat messages remotely.
